package com.example.aclogin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {

    private SignInButton b_google;//구글로그인버튼
    private FirebaseAuth auth;//파이어베이스인증객체
    private GoogleSignInClient googleSignInClient;//google api client
    private static final int REQ_SIGN_GOOGLE = 1; //구글 로그인 결과 코드

    @Override
    protected void onCreate(Bundle savedInstanceState) { //앱이 실행될 때 처음 수행되는 곳
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient= GoogleSignIn.getClient(this,googleSignInOptions);

        auth = FirebaseAuth.getInstance(); //파이어베이스 인증 객체 초기화

        b_google = findViewById(R.id.b_google);
        b_google.setOnClickListener(new View.OnClickListener() { //버튼 클릭 시 실행됨
            @Override
            public void onClick(View view) {
                Intent intent = googleSignInClient.getSignInIntent();//구글에서 제공되는 인증
                startActivityForResult(intent, REQ_SIGN_GOOGLE);

            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { //구글 로그인 인증을 요청했을 때 결과값을 되돌려받는 곳
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQ_SIGN_GOOGLE) {
            Task<GoogleSignInAccount> task=GoogleSignIn.getSignedInAccountFromIntent(data);
            if(task.isSuccessful()){
                GoogleSignInAccount account=task.getResult();//어카운트라는 데이터는 구글로그인 정보를 담고 있음( 닉네임, 프로필 사진, 이메일 등)
                resultlogin(account);//로그인 결과값 출력 수행하라는 메소드
            }
        }
    }

    private void resultlogin(GoogleSignInAccount account) {
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {//로그인이 성공
                            Toast.makeText(MainActivity.this, "로그인이 성공되었습니다", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), NextActivity.class); //NextActivity로 넘어감



                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "로그인이 실패하였습니다", Toast.LENGTH_SHORT).show();

                        }

                    }
                });
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

}